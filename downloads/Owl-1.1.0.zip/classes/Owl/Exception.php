<?php

namespace Owl;

/**
 * Exceptions for the Owl library
 *
 * @package   Owl
 * @author    Dave Widmer <dwidmer@bgsu.edu>
 */
class Exception extends \Exception{}
