<?php

namespace Owl\Engine;

/**
 * The rendering engine using Mustache.
 *
 * @package   Owl
 * @author    Dave Widmer <dwidmer@bgsu.edu>
 */
class Mustache extends \Mustache implements \Owl\Engine{}
